'use strict';

window.customStart = () => {
};
