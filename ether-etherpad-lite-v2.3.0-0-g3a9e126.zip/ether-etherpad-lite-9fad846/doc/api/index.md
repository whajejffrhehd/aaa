# API documentation

This part of the documentation is about the API of Etherpad. It is intended for developers who want to write applications that interact with Etherpad instances or plugins.
