export type LegacyParams = {
    start: number,
    end: number,
    lifetime: number,
    algId: number,
    algParams: any,
    interval:number|null
}