'use strict';


export type PluginType = {
    package: {
        name: string,
        version: string
    }
}