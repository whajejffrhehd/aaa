# Security Policy

## Reporting a Vulnerability

Please email contact@etherpad.org to report security related issues.
