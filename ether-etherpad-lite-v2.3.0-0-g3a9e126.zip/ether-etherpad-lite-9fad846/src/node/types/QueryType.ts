export type QueryType = {
searchTerm: string; sortBy: string; sortDir: string; offset: number; limit: number;
}