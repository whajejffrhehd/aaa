---
name: Security issue
about: Notify the Etherpad foundation of a Security issue
title: ''
labels: security
assignees: ''

---

Please email contact@etherpad.org with details of the security issue prior to posting here.
