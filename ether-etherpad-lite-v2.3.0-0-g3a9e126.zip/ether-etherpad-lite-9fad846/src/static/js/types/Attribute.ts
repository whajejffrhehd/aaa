export type Attribute = [string, string]
