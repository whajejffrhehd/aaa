export type PartType = {
    plugin: string,
    client_hooks:any
}

export type PluginDef = {
    package:{
        path:string
    }
}
