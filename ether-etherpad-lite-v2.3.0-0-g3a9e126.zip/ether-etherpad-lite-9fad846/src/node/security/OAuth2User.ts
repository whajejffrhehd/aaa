export type OAuth2User = {
    username: string;
    password: string;
    admin: boolean;
}
