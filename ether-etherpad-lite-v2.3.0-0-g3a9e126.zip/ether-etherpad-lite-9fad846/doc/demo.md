# Demo of Etherpad

This is a demo of Etherpad. It shows how to use Etherpad and what it can do.

## The toolbar

![The toolbar](/etherpad_basic.png)

## The pad

![The pad](/etherpad_demo.gif)

## Etherpad with a virtual webcam

![Etherpad full features](/etherpad_full_features.png)

## Etherpad skin variants

![Etherpad skin variants](/etherpad_skin_variants.gif)
