export type SecretRotatorType = {
    stop: ()=>void
}