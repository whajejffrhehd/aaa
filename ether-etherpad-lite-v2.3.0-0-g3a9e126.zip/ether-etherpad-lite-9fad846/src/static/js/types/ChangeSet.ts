export type ChangeSet = {
  oldLen: number,
  newLen: number,
  ops: string
  charBank: string
}
